#include <iostream>

//#1 Print i as long as i is less than 6.
int main() {
  
}

// //#2 Use the do/while loop to print i as long as i is less than 6.
// int main() {
  
// }

// //#3 Use a for loop to print "Yes" 5 times:
// int main() {
	
// }

// //#4 Stop the loop if i is 5.
// int main() {
// 	for (int i = 0; i < 10; i++) {
// 	  if (i == 5) {    
// 			_?_ ;
// 	  }
// 	  cout << i << "\n";
// 	}
// }

// //#5 In the following loop, when the value is "4", jump directly to the next value.
// int main() {
// 	for (int i = 0; i < 10; i++) {
// 	  if (i == 4) {
// 	    _?_ ;
// 	  }
// 	  cout << i << "\n";
// 	}
// }

//***************************************
//            ARRAYS
//***************************************

// int main() {
// 	// #1 Create an array of type string called cars.
// 	_?_ _?_[4] = {"Volvo", "BMW", "Ford", "Mazda"};
	
// 	//#2 Complete the for loop to print out the array.
// 	for(int i=0; i < _?_; _?_++;) {
// 		cout << _?_[_?_];
// 	}

// 	//#3 Print the second element in the array

//	//#4 Change the value from "Volvo" to "Opel", in the cars array.
// 	_?_ = _?_; 
// 	cout << cars[0];

// }


