#include <iostream>

//#1 Print "Hello World"
int main() {
  
 	_?_ << "Hello World!";
  return 0;
}

// //#2 Insert a new line after "Hello World", by using a special character:
// int main() {
//   cout << "Hello World! _?_";
//   cout << "I am learning C++";
//   return 0;
// }

// //#3 Create a variable named myNum, assign the value 50 to it and the print it out
// int main() {
//   _?_ _?_ = _?_;
// 	_?_ << _?_;
// }

// //#4 Display the sum of 5 + 10, using two variables: x and y.
// int main() {
//   _?_ _?_ = _?_;
// 	_?_ _?_ = _?_;
// }

// //#5 Create a variable called z, assign x + y to it, and display the result.
// int main() {
	
// }